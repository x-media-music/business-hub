# Scripts — Basis-Werkzeugkasten

Diese Ordnerstruktur ist ein **Gerüst**. Die Scripts selbst sind Platzhalter
und müssen einmalig mit echten Werten konfiguriert werden, sobald du die
Mail-Anbindung aktivieren willst.

## Was hier liegt

| Datei | Zweck | Status |
|---|---|---|
| `azure_app_template.env` | Vorlage für Azure-App-Credentials | **Platzhalter — ausfüllen** |
| `refresh_token.py` | Microsoft-Token frisch halten | Template |
| `send_email.py` | Mail-Versand über Graph API (mit Gate-Hash, Logging) | Template |
| `check_inbox.py` | Inkrementeller Inbox-Check mit Cursor | Template |

## Azure-App einrichten (einmalig, ca. 15 Min)

Wenn du willst, dass Claude dein Outlook/M365-Postfach direkt lesen und
Entwürfe anlegen kann, brauchst du eine eigene App-Registrierung.

1. **Portal öffnen:** https://portal.azure.com → „App-Registrierungen" → „Neue Registrierung"
2. **Name:** `[Dein-Name]-Business-Hub-Claude`
3. **Unterstützte Kontotypen:** „Nur Konten in diesem Organisationsverzeichnis"
   (oder je nach Mailhoster „Persönliche Konten" zulassen)
4. **Umleitungs-URI:** `http://localhost:8080` (Typ „Web")
5. Nach dem Anlegen die Werte notieren:
   - **Anwendungs-(Client)-ID** → in `azure_app_template.env` als `CLIENT_ID`
   - **Verzeichnis-(Mandanten)-ID** → als `TENANT_ID`
6. **API-Berechtigungen → Microsoft Graph → Delegierte Berechtigungen:**
   - `Mail.ReadWrite`
   - `Mail.Send`
   - `User.Read`
   - `offline_access`
7. **Zertifikate & Geheimnisse → Neuer geheimer Clientschlüssel** — Wert
   sofort kopieren (wird danach nicht mehr angezeigt) → als `CLIENT_SECRET`
8. `azure_app_template.env` in `azure_app.env` umbenennen und mit deinen
   Werten füllen (Datei ist in `.gitignore` — bleibt lokal!)
9. Einmal `python refresh_token.py --initial-login` laufen lassen — öffnet
   Browser zum Login, speichert Refresh-Token.

Danach laufen `send_email.py` und `check_inbox.py` autonom.

## Sicherheit

- `azure_app.env` und `tokens/` sind in `.gitignore` — niemals in ein Repo
  pushen oder mit anderen teilen
- Bei Verdacht auf Kompromittierung: in Azure Portal → App-Registrierung →
  Geheimnis widerrufen + neu generieren
