"""
send_email.py — Template für Email-Versand via Microsoft Graph.

PLATZHALTER-SCRIPT — nach Azure-App-Setup mit Leben füllen. Siehe README.md.

Zweck (wenn produktiv):
- Zentraler Sender für ALLE ausgehenden Mails
- OWNER-GATE-Check (Signatur + Betreff vor Versand gezeigt)
- Gate-Hash-Prüfung (MD5 des freigegebenen Texts)
- Guard: blockt .docx/.xlsx an externe Empfänger (Office-Formate → Office-Opt-in)
- Logging in logs/email_versand.log
- Wissensbasis-Hook: trägt Versand-Zeile in Wissensbasis ein

Basis-Muster (funktioniert, wenn azure_app.env befüllt + refresh_token.py
einmal gelaufen ist):

    python send_email.py \
        --to empfaenger@beispiel.de \
        --subject "Betreff" \
        --body-file entwurf.md \
        --absender owner \
        --gate-hash <md5_des_freigegebenen_texts>
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser(description="Zentraler Mail-Sender via MS Graph")
    ap.add_argument("--to", required=True, help="Empfängeradresse(n), Komma-getrennt")
    ap.add_argument("--cc", default="", help="CC-Adressen, Komma-getrennt")
    ap.add_argument("--subject", required=True)
    ap.add_argument("--body-file", required=True, help="Pfad zur Body-Datei (.md/.txt/.html)")
    ap.add_argument("--absender", choices=["owner", "sekretaerin"], default="owner")
    ap.add_argument("--gate-hash", default="", help="MD5 des freigegebenen Texts (Empfohlen)")
    ap.add_argument("--importance", choices=["normal", "high"], default="normal")
    ap.add_argument("--allow-office", action="store_true", help="Office-Anhang an Externe zulassen")
    ap.add_argument("--attach", action="append", default=[], help="Pfad zu Anhang (wiederholbar)")
    args = ap.parse_args()

    print("⚠️  Dieses Script ist ein TEMPLATE. Vor erstem Versand:")
    print("    1. scripts/azure_app.env füllen (siehe scripts/README.md)")
    print("    2. python refresh_token.py --initial-login")
    print("    3. Graph-API-Aufruf unten implementieren (msal + requests).")
    print()
    print("Abgelesene Argumente:")
    for k, v in vars(args).items():
        print(f"   {k}: {v}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
