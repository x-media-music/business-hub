"""
check_inbox.py — Template für inkrementellen Inbox-Check.

PLATZHALTER-SCRIPT — nach Azure-App-Setup mit Leben füllen. Siehe README.md.

Zweck (wenn produktiv):
- „Neue Mails seit letztem Mal?" — via persistenten Cursor in
  backups/inbox_state.json
- Ad-hoc-Modus für freien Zeitraum (Cursor unverändert)
- Hard-Limit: max. 50 Mails pro Aufruf

Nutzung:
    python check_inbox.py                 # neue seit letztem Cursor
    python check_inbox.py --since 2026-05-01
    python check_inbox.py --between 2026-05-01..2026-05-10
"""
from __future__ import annotations

import argparse
import sys


def main() -> int:
    ap = argparse.ArgumentParser(description="Inkrementeller Inbox-Check")
    ap.add_argument("--top", type=int, default=50)
    ap.add_argument("--since")
    ap.add_argument("--to", dest="to_date")
    ap.add_argument("--between")
    ap.add_argument("--cursor-show", action="store_true")
    ap.add_argument("--cursor-reset")
    args = ap.parse_args()

    print("⚠️  Dieses Script ist ein TEMPLATE.")
    print("    Vor erstem Lauf: scripts/azure_app.env + refresh_token.py einrichten.")
    print()
    print("Abgelesene Argumente:", vars(args))
    return 0


if __name__ == "__main__":
    sys.exit(main())
