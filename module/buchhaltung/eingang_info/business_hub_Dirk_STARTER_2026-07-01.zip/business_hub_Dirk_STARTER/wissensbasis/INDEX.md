# Wissensbasis — Index

_(Wird beim „Ende"-Befehl oder manuell via `scripts/wissensbasis_index.py`
aktualisiert. Zeigt alle Einträge A–Z auf einen Blick.)_
