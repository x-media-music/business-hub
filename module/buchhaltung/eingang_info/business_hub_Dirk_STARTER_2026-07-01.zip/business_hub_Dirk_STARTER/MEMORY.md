# Memory Index — {{OWNER_NAME}}s Business-Hub

Persistenter Speicher. Details in den verlinkten Dateien.

_(Dieser Index wird nach dem Onboarding und im Laufe der Arbeit gefüllt.
Format pro Eintrag: `- [Titel](datei.md) — einzeilige Kurzbeschreibung`)_

## ⭐ NORDSTERN

_(Kernregeln und Disziplinen, die über allem stehen — leer bis nach Onboarding)_

## Feedback

_(Korrekturen/Bestätigungen durch den Owner — wie will er arbeiten)_

## User

_(Wer ist der Owner, Rolle, Präferenzen, Hintergrund)_

## Project

_(Laufende Vorgänge, Fristen, strategische Themen)_

## Reference

_(Verweise auf externe Systeme, Ordner, Dashboards)_


---

## Pre-Seed: Universal-Mantel-Memories

In `memory/` liegen 14 vorgefertigte Mantel-Memories (Mindset, Externe Kommunikation, Hub-Disziplin) - siehe `memory/MEMORY.md`.

Diese decken die wichtigsten universellen Regeln ab. Du kannst sie:
- direkt uebernehmen (Default)
- anpassen (Inhalt editieren, Verweise auf {{OWNER_NAME}} ersetzen)
- loeschen, falls sie nicht zu deiner Arbeitsweise passen

Eigene Memories einfach ergaenzen - Index pflegen wie oben.
