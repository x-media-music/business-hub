# Session-Protokoll

_(Beim ersten Start: mit Onboarding-Datum/-Stichworten füllen.
Ab dann pro Session stichwortartig fortführen — Pflicht, nicht optional.)_
