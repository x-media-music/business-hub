# CLAUDE.md — Business-Hub von {{OWNER_NAME}}

**Sprache:** Deutsch · **Antwort-Stil:** Kurz, knapp, Tabellen wenn sinnvoll

---

## ⚠️ BEIM ALLERERSTEN CHAT-START (wichtig!)

Wenn diese Datei noch die Platzhalter `{{OWNER_NAME}}`, `{{OWNER_EMAIL}}` etc.
enthält → **der Hub ist noch nicht konfiguriert**. Dann:

1. `ONBOARDING.md` vollständig lesen
2. Dem Onboarding-Ablauf dort Schritt für Schritt folgen
3. Am Ende diese `CLAUDE.md` + `.claude/rules/00_core.md` mit den echten Daten
   überschreiben und `MEMORY.md` anlegen

Wenn die Platzhalter weg sind → Hub ist live, normale Arbeit.

---

## OWNER

- **Name:** {{OWNER_NAME}}
- **Rolle:** {{OWNER_ROLE}}  _(z. B. „Patentanwalt")_
- **Kanzlei/Firma:** {{OWNER_FIRMA}}
- **Adresse:** {{OWNER_ADRESSE}}
- **Telefon:** {{OWNER_TEL}}
- **Mobil:** {{OWNER_MOBIL}}
- **Email:** {{OWNER_EMAIL}}
- **Website:** {{OWNER_WEB}}

## SEKRETÄRIN (optional)

- **Einsatz:** {{SEKRETAERIN_JA_NEIN}}   _(ja / nein)_
- **Name:** {{SEKRETAERIN_NAME}}
- **Rolle:** virtuelle Sekretärin — schreibt formelle Mails i. A. von {{OWNER_NAME}}
- **Signatur-Zusatz:** `– Sekretariat {{OWNER_NAME}} –`

## MODUL-ROUTING

| Schlüsselwörter | Regel-Datei |
|---|---|
| Anfrage, Angebot, Vertrag, Buchung, Event, Info Sheet, Nachbereitung | `.claude/rules/01_booking.md` |
| Akquise, Lead, Recherche, Tannenbaum, Sammelkorb, Kaltakquise, Follow-up, Bounce | `.claude/rules/02_akquise.md` |
| _(weitere Module werden ergänzt wenn du welche definierst)_ | |

> **Vorgebaut:** Booking + Akquise (inkl. Tannenbaum-Prinzip) liegen bereits als leeres, funktionierendes Gerüst bereit — siehe `ANLEITUNG.md`, wie du sie steuerst.

## REGELSYSTEM

Alle Regeln liegen in `.claude/rules/`:

| Datei | Inhalt |
|---|---|
| `00_core.md` | **Kernregeln — IMMER laden.** OWNER-GATE, 5 absolute Regeln, Signaturen, Email-Regeln, Session-Workflow. |
| `01_booking.md` / `02_akquise.md` | Fachliche Module (vorgebaut; weitere im Onboarding) |

## BEI SESSION-START

1. **Datum + Uhrzeit frisch ziehen:**
   `python -c "from datetime import datetime; print(datetime.now().strftime('%d.%m.%Y %H:%M:%S (%A)'))"`
2. `MEMORY.md` lesen (aktueller Status, offene Vorgänge)
3. `logs/session_checkpoint.md` prüfen — falls vorhanden = letzte Session war
   Crash, {{OWNER_NAME}} informieren was offen war
4. `logs/session_protokoll.md` anlegen/fortführen (Pflicht, nicht optional)
5. (Wenn Mail-Anbindung konfiguriert:) Inbox-Check vorschlagen

## ABSOLUTE REGELN

- **NIEMALS** Aktion nach außen ohne OWNER-GATE (Email, Brief, Post, Anruf)
- **NIEMALS** Email senden ohne explizites „Ja" / „senden" / „raus damit"
- **NIEMALS** Daten löschen/überschreiben ohne Backup
- **NIEMALS** Zahlungen, Käufe, Abos ohne OWNER
- **IMMER** bei Unsicherheit: FRAGEN

## PFADE

| Was | Pfad |
|---|---|
| Hub-Root | `{{HUB_ROOT}}` |
| Module | `{{HUB_ROOT}}/module/` |
| Scripts | `{{HUB_ROOT}}/scripts/` |
| Backups | `{{HUB_ROOT}}/backups/` |
| Logs | `{{HUB_ROOT}}/logs/` |
| Reports | `{{HUB_ROOT}}/reports/` |
| Vorlagen | `{{HUB_ROOT}}/vorlagen/` |
| Wissensbasis | `{{HUB_ROOT}}/wissensbasis/` |
| Ansicht-Dokumente (Staging) | `{{HUB_ROOT}}/Ansicht Dokumente/hub_Owner/` |
